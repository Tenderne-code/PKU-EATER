就，
测试以下fragment的上下简单拖动效果
